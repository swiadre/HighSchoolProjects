﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Firma
{
    [Serializable]
    public class CzlonekZespolu : Osoba, ICloneable, IComparable<CzlonekZespolu>
    {
        [XmlElement]
        private DateTime dataZapisu;
        [XmlElement]
        public string funkcja;

        public CzlonekZespolu(string imie, string nazwisko, string data_urodzenia, string Pesel, Plcie plec, string funkcja, string dataZapisu) : base(imie, nazwisko, data_urodzenia, Pesel, plec)
        {
            DateTime.TryParseExact(dataZapisu, new[] { "dd-MMM-yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out this.dataZapisu);
            this.funkcja = funkcja;
        }

        public CzlonekZespolu()
        {
        }

        public DateTime DataZapisu => dataZapisu;

        public override string ToString()
        {
            return base.ToString() + $" - {funkcja} ({dataZapisu:dd-MMM-yyyy})";
        }
        public new object Clone()
        {
            return new CzlonekZespolu(Imie, Nazwisko, DataUrodzenia.ToString("yyyy-MM-dd"), GetPESEL(), GetPlec(), funkcja, DataZapisu.ToString("dd-MMM-yyyy"));
        }

        public int CompareTo(CzlonekZespolu other)
        {
            int result = Nazwisko.CompareTo(other.Nazwisko);
            if (result == 0)
            {
                result = Imie.CompareTo(other.Imie);
            }
            return result;
        }
    }
}
