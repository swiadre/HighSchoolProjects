﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace Firma
{
    [Serializable]
    [XmlRoot("Zespol")]
    public class Zespol : ICloneable
    {
        [XmlElement]
        private int liczbaCzlonkow;

        [XmlElement]
        public string nazwa;

        [XmlElement]
        private KierownikZespolu kierownik;

        [XmlElement]
        public List<CzlonekZespolu> czlonkowie;

        public Zespol()
        {
            liczbaCzlonkow = 0;
            nazwa = null;
            kierownik = null;
            czlonkowie = new List<CzlonekZespolu>();
        }

        public Zespol(string nazwa, KierownikZespolu kierownik) : this()
        {
            this.nazwa = nazwa;
            this.kierownik = kierownik;
        }

        public int LiczbaCzlonkow => liczbaCzlonkow;
        public string Nazwa => nazwa;
        public KierownikZespolu Kierownik => kierownik;

        public void DodajCzlonka(CzlonekZespolu czlonek)
        {
            czlonkowie.Add(czlonek);
            liczbaCzlonkow++;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Zespół: {nazwa}");
            sb.AppendLine($"Kierownik: {kierownik}");
            sb.AppendLine("Członkowie zespołu:");
            foreach (var czlonek in czlonkowie)
            {
                sb.AppendLine($"{czlonek}");
            }
            return sb.ToString();
        }
        public bool JestCzlonkiem(string PESEL)
        {
            return czlonkowie.Any(czlonek => czlonek.ToString().Contains(PESEL));
        }

        public bool JestCzlonkiem(string imie, string nazwisko)
        {
            return czlonkowie.Any(czlonek => czlonek.ToString().Contains(imie) && czlonek.ToString().Contains(nazwisko));
        }
        public void UsunCzlonka(string PESEL)
        {
            CzlonekZespolu czlonekToRemove = czlonkowie.FirstOrDefault(czlonek => czlonek.ToString().Contains(PESEL));
            if (czlonekToRemove != null)
            {
                czlonkowie.Remove(czlonekToRemove);
                liczbaCzlonkow--;
            }
        }

        public void UsunCzlonka(string imie, string nazwisko)
        {
            CzlonekZespolu czlonekToRemove = czlonkowie.FirstOrDefault(czlonek => czlonek.ToString().Contains(imie) && czlonek.ToString().Contains(nazwisko));
            if (czlonekToRemove != null)
            {
                czlonkowie.Remove(czlonekToRemove);
                liczbaCzlonkow--;
            }
        }

        public void UsunWszystkich()
        {
            czlonkowie.Clear();
            liczbaCzlonkow = 0;
        }
        public List<CzlonekZespolu> WyszukajCzlonkow(string funkcja)
        {
            return czlonkowie.FindAll(czlonek => czlonek.ToString().Contains(funkcja));
        }

        public List<CzlonekZespolu> WyszukajCzlonkow(int miesiac)
        {
            return czlonkowie.FindAll(czlonek => czlonek.DataZapisu.Month == miesiac);
        }

        public object Clone()
        {
            Zespol nowyZespol = new Zespol(this.Nazwa, (KierownikZespolu)this.Kierownik.Clone());

            foreach (var czlonek in this.czlonkowie)
            {
                nowyZespol.DodajCzlonka((CzlonekZespolu)czlonek.Clone());
            }

            return nowyZespol;
        }

        public void Sortuj()
        {
            czlonkowie.Sort();
        }
        public class PESELComparator : IComparer<CzlonekZespolu>
        {
            public int Compare(CzlonekZespolu x, CzlonekZespolu y)
            {
                return x.GetPESEL().CompareTo(y.GetPESEL());
            }
        }

        public void SortujPoPESEL()
        {
            czlonkowie.Sort(new PESELComparator());
        }

        public bool JestCzlonkiem(CzlonekZespolu czlonek)
        {
            return czlonkowie.Any(c => c.Equals(czlonek));
        }

        public static void ZapiszBin(Zespol zespol, string nazwa)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream fs = new FileStream(nazwa, FileMode.Create))
            {
                formatter.Serialize(fs, zespol);
            }
        }

        public static Zespol OdczytajBin(string nazwa)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream fs = new FileStream(nazwa, FileMode.Open))
            {
                return (Zespol)formatter.Deserialize(fs);
            }
        }


        public static void ZapiszXML(Zespol zespol, string filePath)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Zespol));

            using (FileStream fs = new FileStream("C:\\Users\\maxym\\OneDrive\\Pulpit\\firmaaa\\Firma\\zespol.xml", FileMode.Create))
            {
                serializer.Serialize(fs, zespol);
            }

            Console.WriteLine("Obiekt został zserializowany do pliku XML.");
            
        }

        public static Zespol OdczytajXML(string filePath)
        {

            XmlSerializer serializer = new XmlSerializer(typeof(Zespol));

            using (FileStream fs = new FileStream("C:\\Users\\maxym\\OneDrive\\Pulpit\\firmaaa\\Firma\\zespol.xml", FileMode.Open))
            {
                return (Zespol)serializer.Deserialize(fs);
            }
        }
        public void ZmienNazweIKierownika(string nowaNazwa, KierownikZespolu nowyKierownik)
        {
            this.nazwa = nowaNazwa;
            this.kierownik = nowyKierownik;
        }
    }
}
