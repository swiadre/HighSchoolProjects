﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    [Serializable]
    public class Osoba : IEquatable<Osoba>, ICloneable
    {
        public enum Plcie { K, M }

        private string imie;
        public string Nazwisko { get; set; }
        private DateTime dataUrodzenia;
        public string PESEL;
        public Plcie plec;

        public string Imie
        {
            get { return imie; }
            set { imie = value; }
        }

        public DateTime DataUrodzenia
        {
            get => dataUrodzenia;
            set => dataUrodzenia = value;
        }

        public Osoba()
        {
            imie = "DomyślneImie";
            Nazwisko = "DomyślneNazwisko";
            dataUrodzenia = DateTime.Now;
            PESEL = "00000000000";
        }

        public Osoba(string imie, string nazwisko)
        {
            Imie = imie;
            Nazwisko = nazwisko;
        }

        public Osoba(string imie, string nazwisko, string data_urodzenia, string Pesel, Plcie plec)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            DateTime.TryParseExact(data_urodzenia, new[] { "yyyy-MM-dd", "yyyy/MM/dd", "MM/dd/yy", "dd-MMM-yy" }, null, DateTimeStyles.None, out dataUrodzenia);
            PESEL = Pesel;
            this.plec = plec;
        }

        public int Wiek()
        {
            return DateTime.Now.Year - dataUrodzenia.Year;
        }

        public override string ToString()
        {
            int wiek = Wiek();
            return $"{PESEL} - {Imie} {Nazwisko} ({wiek} lat)";
        }

        public string GetPESEL()
        {
            return PESEL;
        }

        public Plcie GetPlec()
        {
            return plec;
        }

        public object Clone()
        {
            return new Osoba(Imie, Nazwisko, DataUrodzenia.ToString("yyyy-MM-dd"), PESEL, plec);
        }

        public bool Equals(Osoba other)
        {
            return this.PESEL == other.PESEL;
        }
    }
}
