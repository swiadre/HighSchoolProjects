﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Firma
{
    [Serializable]
    public class KierownikZespolu : Osoba, ICloneable
    {
        [XmlElement]
        public int doswiadczenie;


        public KierownikZespolu(string imie, string nazwisko, string data_urodzenia, string Pesel, Plcie plec, int doswiadczenie)
            : base(imie, nazwisko, data_urodzenia, Pesel, plec)
        {
            this.doswiadczenie = doswiadczenie;
        }

        public override string ToString()
        {
            return base.ToString() + $" - Doswiadczenie: {doswiadczenie} lat";
        }

        public new object Clone()
        {
            return new KierownikZespolu(Imie, Nazwisko, DataUrodzenia.ToString("yyyy-MM-dd"), GetPESEL(), GetPlec(), doswiadczenie);
        }
    }
}
