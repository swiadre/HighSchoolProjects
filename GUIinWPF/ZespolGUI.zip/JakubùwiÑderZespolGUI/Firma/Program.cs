﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using static Firma.Osoba;

namespace Firma
{
    internal class Program
    {
        static void Main(string[] args)
        {
            KierownikZespolu adamKierownik = new KierownikZespolu("Adam", "Kowalski", "1990-07-01", "90070142412", Osoba.Plcie.M, 5);

            CzlonekZespolu witold = new CzlonekZespolu("Witold", "Adamski", "1992-10-22", "92102266738", Osoba.Plcie.M, "sekretarz", "01-Jan-2020");
            CzlonekZespolu jan = new CzlonekZespolu("Jan", "Janowski", "1992-03-15", "92031532652", Osoba.Plcie.M, "programista", "01-Jun-2019");
            CzlonekZespolu janBut = new CzlonekZespolu("Jan", "But", "1992-05-16", "92051613915", Osoba.Plcie.M, "programista", "01-Jun-2019");
            CzlonekZespolu beata = new CzlonekZespolu("Beata", "Nowak", "1993-11-22", "93112225023", Osoba.Plcie.K, "projektant", "01-Jun-2018");
            CzlonekZespolu anna = new CzlonekZespolu("Anna", "Mysza", "1991-07-22", "91072235964", Osoba.Plcie.K, "projektant", "01-Jun-2018");

            Zespol grupaIT = new Zespol("Grupa IT", adamKierownik);
            grupaIT.DodajCzlonka(witold);
            grupaIT.DodajCzlonka(jan);
            grupaIT.DodajCzlonka(janBut);
            grupaIT.DodajCzlonka(beata);
            grupaIT.DodajCzlonka(anna);

            // zapis do xml
            string filePath = "C:\\Users\\Public\\Documents\\firmaaa\\Firma\\bin\\Debug\\zespol.bin";
            Zespol.ZapiszBin(grupaIT, filePath);
            Zespol zespolBin = Zespol.OdczytajBin(filePath);

            Console.WriteLine("\nZespół wczytany z pliku XML:");
            Console.WriteLine(zespolBin.LiczbaCzlonkow);


            Console.ReadLine();
        }
    }
}
