﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using Firma;

namespace ZespolGUI
{
    public partial class MainWindow : Window
    {
        private Zespol zespol = new Zespol();
        private bool czyZapisano = false;

        public MainWindow()
        {
            InitializeComponent();

           
            Closing += MainWindow_Closing;
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!czyZapisano)
            {
                MessageBoxResult result = MessageBox.Show("Czy chcesz zapisać zmiany przed zamknięciem aplikacji?", "Zapis zmian", MessageBoxButton.YesNoCancel);
                if (result == MessageBoxResult.Yes)
                {
                    MenuZapisz_Click(null, null);
                }
                else if (result == MessageBoxResult.Cancel)
                {
              
                    e.Cancel = true;
                }
            }
        }

        

        private void btnDodaj_Click(object sender, RoutedEventArgs e)
        {
            CzlonekZespolu cz = new CzlonekZespolu();
            OsobaWindow okno = new OsobaWindow(cz);
            okno.ShowDialog();
            zespol.DodajCzlonka(cz);
            lstCzlonkowie.ItemsSource = new ObservableCollection<CzlonekZespolu>(zespol.czlonkowie);
            czyZapisano = false;
        }

        private void btnUsun_Click(object sender, RoutedEventArgs e)
        {
            if (lstCzlonkowie.SelectedItem != null)
            {
                int zaznaczony = lstCzlonkowie.SelectedIndex;
                zespol.czlonkowie.RemoveAt(zaznaczony);
                lstCzlonkowie.ItemsSource = new ObservableCollection<CzlonekZespolu>(zespol.czlonkowie);
                czyZapisano = false;
            }
            else
            {
                MessageBox.Show("Proszę wybrać członka z listy.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MenuOtworz_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string filename = dlg.FileName;
                zespol = Zespol.OdczytajBin(filename);
                lstCzlonkowie.ItemsSource = new ObservableCollection<CzlonekZespolu>(zespol.czlonkowie);
                txtNazwa.Text = zespol.Nazwa;
                txtKierownik.Text = $"{zespol.Kierownik.Imie} {zespol.Kierownik.Nazwisko}";
                czyZapisano = false;
            }
        }

        private void MenuWyjdz_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void MenuZapisz_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string filename = dlg.FileName;
                zespol.nazwa = txtNazwa.Text;
                Zespol.ZapiszBin(zespol, filename);
                czyZapisano = true;
            }
        }
        private void btnZmien_Click(object sender, RoutedEventArgs e)
        {
            OsobaWindow okno = new OsobaWindow(zespol.Kierownik);
            okno.ShowDialog();
            txtKierownik.Text = $"{zespol.Kierownik.Imie} {zespol.Kierownik.Nazwisko}";
            czyZapisano = false;
        }
        private void btnZmien2_Click(object sender, RoutedEventArgs e)
        {
            if (lstCzlonkowie.SelectedItem != null)
            {
                CzlonekZespolu wybranyCzlonek = (CzlonekZespolu)lstCzlonkowie.SelectedItem;

                OsobaWindow okno = new OsobaWindow(wybranyCzlonek);
                if (okno.ShowDialog() == true)
                {
                    lstCzlonkowie.ItemsSource = new ObservableCollection<CzlonekZespolu>(zespol.czlonkowie);
                }
            }
            else
            {
                MessageBox.Show("Proszę wybrać członka z listy.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
