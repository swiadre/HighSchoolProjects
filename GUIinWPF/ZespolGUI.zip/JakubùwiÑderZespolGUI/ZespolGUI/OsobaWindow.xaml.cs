﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Firma;

namespace ZespolGUI
{
    /// <summary>
    /// Logika interakcji dla klasy OsobaWindow.xaml
    /// </summary>
    public partial class OsobaWindow : Window
    {
        private Osoba _osoba;

        public OsobaWindow()
        {
            InitializeComponent();
        }

        public OsobaWindow(Osoba osoba) : this()
        {
            _osoba = osoba;

            if (_osoba is KierownikZespolu)
            {
                lblFunkcja.Content = "Doświadczenie:";
                txtFunkcja.Text = ((KierownikZespolu)_osoba).doswiadczenie.ToString();
            }
            else if (_osoba is CzlonekZespolu)
            {
                lblFunkcja.Content = "Funkcja:";
                txtFunkcja.Text = ((CzlonekZespolu)_osoba).funkcja;
            }

            txtPesel.Text = _osoba.GetPESEL();
            txtImie.Text = _osoba.Imie;
            txtNazwisko.Text = _osoba.Nazwisko;
            txtDataUrodzenia.Text = _osoba.DataUrodzenia.ToString("dd-MMM-yyyy");
            cmbPlec.Text = (_osoba.plec == Osoba.Plcie.K) ? "kobieta" : "mężczyzna";
        }

        private void btnZatwierdz_Click(object sender, RoutedEventArgs e)
        {
            if (txtPesel.Text != "" && txtImie.Text != "" && txtNazwisko.Text != "")
            {
                _osoba.PESEL = txtPesel.Text;
                _osoba.Imie = txtImie.Text;
                _osoba.Nazwisko = txtNazwisko.Text;

                DateTime date;
                if (DateTime.TryParse(txtDataUrodzenia.Text, out date))
                {
                    _osoba.DataUrodzenia = date;
                    _osoba.plec = (cmbPlec.Text == "kobieta") ? Osoba.Plcie.K : Osoba.Plcie.M;

                    if (_osoba is KierownikZespolu)
                    {
                        int doswiadczenie;
                        if (int.TryParse(txtFunkcja.Text, out doswiadczenie))
                        {
                            ((KierownikZespolu)_osoba).doswiadczenie = doswiadczenie;
                        }
                        else
                        {
                            MessageBox.Show("Niepoprawna wartość doświadczenia. Proszę wprowadzić liczbę całkowitą.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                    }
                    else if (_osoba is CzlonekZespolu)
                    {
                        ((CzlonekZespolu)_osoba).funkcja = txtFunkcja.Text;
                    }

                    DialogResult = true;
                }
                else
                {
                    MessageBox.Show("Niepoprawny format daty urodzenia: " + txtDataUrodzenia.Text, "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Proszę uzupełnić wszystkie pola.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void btnAnuluj_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }

}
