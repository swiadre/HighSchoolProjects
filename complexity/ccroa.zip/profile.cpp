#include<iostream>
#include <ctime>
#include <algorithm>
#include <cstdlib>

using namespace std;

int partition(int arr[], int start, int end)
{
 
    int pivot = arr[start];
 
    int count = 0;
    for (int i = start + 1; i <= end; i++) {
        if (arr[i] <= pivot)
            count++;
    }
 
    int pivotIndex = start + count;
    swap(arr[pivotIndex], arr[start]);
 
    int i = start, j = end;
 
    while (i < pivotIndex && j > pivotIndex) {
 
        while (arr[i] <= pivot) {
            i++;
        }
 
        while (arr[j] > pivot) {
            j--;
        }
 
        if (i < pivotIndex && j > pivotIndex) {
            swap(arr[i++], arr[j--]);
        }
    }
 
    return pivotIndex;
}
 
void quickSort(int arr[], int start, int end)
{
 
    if (start >= end)
        return;
 
    int p = partition(arr, start, end);
 
    quickSort(arr, start, p - 1);
 
    quickSort(arr, p + 1, end);
}

void bubbleSort(int n)
{
    int arr[n];
    for(int i = 0; i < n; i++){
        srand(time(NULL));
        arr[i] = rand() % 100;
    }
    int i, j;
    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - i - 1; j++)
            if (arr[j] > arr[j + 1])
                swap(arr[j], arr[j + 1]);
}

void quickSortStart(int n){
    int arr[n];
    for(int i = 0; i < n; i++){
        srand(time(NULL));
        arr[i] = rand() % 100;
    }
    quickSort(arr, arr[0], arr[n]);
}

float Profile(int num){
    float v;
    float ttab[num];
    clock_t t1;
    clock_t t2;
    
    for (int i = 0; i < num; i++){
        t1 = clock();
        // bubbleSort(num);
        quickSortStart(num);
        t2 = clock();
    
        ttab[i] = (float)(t2 - t1) / CLOCKS_PER_SEC;
    }
    
    sort(ttab, ttab+num);
    v = 0.0f;
    for(int i=1; i < num - 1; i++){
        v = v + ttab[i];
    }
    v/= (float)(num - 2.0f);
    
    return v;
}

int main()
{
    for(int i = 1; i <= 18; i++)
    cout << Profile(i*100) << '\n';
}