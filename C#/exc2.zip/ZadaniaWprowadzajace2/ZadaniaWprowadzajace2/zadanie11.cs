﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ZadaniaWprowadzajace2
{
    internal class zadanie11
    {
        public static void PerformCalculationAndPrint()
        {
            Console.WriteLine("Wpisz pierwsza liczbe:");
            double num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Wybierz operacje (+, -, *, /):");
            char operation = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("Wpisz druga liczbe:");
            double num2 = Convert.ToDouble(Console.ReadLine());

            double result = PerformCalculation(num1, num2, operation);

            Console.WriteLine($"{num1,10}\n{operation,9} {num2,8}\n{"=",10}\n{result,10}");
        }

        private static double PerformCalculation(double num1, double num2, char operation)
        {
            switch (operation)
            {
                case '+':
                    return num1 + num2;
                case '-':
                    return num1 - num2;
                case '*':
                    return num1 * num2;
                case '/':
                    if (num2 != 0)
                        return num1 / num2;
                    else
                    {
                        Console.WriteLine("Nie dziel przez zero.");
                        return double.NaN;
                    }
                default:
                    Console.WriteLine("Nie ma takiej operacji.");
                    return double.NaN;
            }
        }
    }
}
