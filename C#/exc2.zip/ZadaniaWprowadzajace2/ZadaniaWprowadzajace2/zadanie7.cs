﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadaniaWprowadzajace2
{
    internal class zadanie7
    {
        public static void GenerateAndPrint()
        {
            int size = 7;
            int[][] pascalTriangle = GeneratePascalTriangle(size);

            Console.WriteLine("Trojkat Pascala:");
            PrintPascalTriangle(pascalTriangle);
        }

        private static int[][] GeneratePascalTriangle(int size)
        {
            int[][] triangle = new int[size][];
            for (int i = 0; i < size; i++)
            {
                triangle[i] = new int[i + 1];
                triangle[i][0] = 1;
                triangle[i][i] = 1;

                for (int j = 1; j < i; j++)
                {
                    triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j];
                }
            }
            return triangle;
        }

        private static void PrintPascalTriangle(int[][] triangle)
        {
            foreach (var row in triangle)
            {
                foreach (var number in row)
                {
                    Console.Write(number + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
