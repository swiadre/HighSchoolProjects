﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadaniaWprowadzajace2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            zadanie6.SortAndPrint();

            zadanie7.GenerateAndPrint();

            zadanie8.CalculateAndPrint();

            zadanie8_1.CalculateAndPrint();

            zadanie9.CalculateAndPrint();

            zadanie10.DrawFigure();

            zadanie11.PerformCalculationAndPrint();

            Console.ReadLine();
        }
    }
}
