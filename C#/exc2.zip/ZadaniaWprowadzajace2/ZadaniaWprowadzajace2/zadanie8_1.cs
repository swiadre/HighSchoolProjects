﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadaniaWprowadzajace2
{
    internal class zadanie8_1
    {
        public static void CalculateAndPrint()
        {
            int n = 5;
            int k = 2;
            int symbolNewtona = CalculateNewtonSymbol(n, k);

            Console.WriteLine($"Symbol Newtona({n}, {k}) = {symbolNewtona}");
        }

        private static int CalculateNewtonSymbol(int n, int k)
        {
            if (k == 0 || k == n)
                return 1;
            else
                return CalculateNewtonSymbol(n - 1, k - 1) + CalculateNewtonSymbol(n - 1, k);
        }
    }
}
