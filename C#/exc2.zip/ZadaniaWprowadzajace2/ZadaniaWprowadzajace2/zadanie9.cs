﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadaniaWprowadzajace2
{
    internal class zadanie9
    {
        public static void CalculateAndPrint()
        {
            DateTime currentDate = DateTime.Now;
            int daysToNewYear = CalculateDaysUntilEndOfYear(currentDate);

            Console.WriteLine($"Dni do konca roku: {daysToNewYear}");
        }

        private static int CalculateDaysUntilEndOfYear(DateTime currentDate)
        {
            DateTime endOfYear = new DateTime(currentDate.Year, 12, 31);
            return (endOfYear - currentDate).Days;
        }
    }
}
