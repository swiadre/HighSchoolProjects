﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadaniaWprowadzajace2
{
    internal class zadanie8
    {
        public static void CalculateAndPrint()
        {
            int a = 48;
            int b = 18;
            int nwd = CalculateNWD(a, b);

            Console.WriteLine($"NWD({a}, {b}) = {nwd}");
        }

        private static int CalculateNWD(int a, int b)
        {
            if (b == 0)
                return a;
            else
                return CalculateNWD(b, a % b);
        }
    }
}
