﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadaniaWprowadzajace2
{
    internal class zadanie10
    {
        public static void DrawFigure()
        {
            int n = 7;
            for (int i = 1; i <= n; i += 2)
            {
                string spaces = new string(' ', (n - i) / 2);
                string stars = new string('*', i);
                Console.WriteLine(spaces + stars);
            }
        }
    }
}
