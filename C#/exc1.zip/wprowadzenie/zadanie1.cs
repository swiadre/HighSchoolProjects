﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime;

namespace wprowadzenie
{
    internal class zadanie1
    {
        private decimal a;
        private float b;

        public zadanie1() { }

        public void wpisz()
        {
            a = Convert.ToDecimal(Console.ReadLine());
            b = float.Parse(Console.ReadLine());
        }
        
        public decimal suma()
        {
            return Math.Round(a + (decimal)b, 2);
        }

        public decimal roznica()
        {
            return Math.Round(a - (decimal)b, 2);
        }

        public decimal iloczyn()
        {
            return Math.Round(a * (decimal)b, 2);
        }

        public decimal iloraz()
        {
            return Math.Round(a / (decimal)b, 2);
        }

        public virtual void wypisz()
        {
            Console.WriteLine("suma: " + suma());
            Console.WriteLine("roznica: " + roznica());
            Console.WriteLine("iloczyn: " + iloczyn());
            Console.WriteLine("iloraz: " + iloraz());
        }
    }
}
