﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wprowadzenie
{
    internal class zadanie2
    {
        private int x;

        public zadanie2() { }

        public void wpisz()
        {
            x = Convert.ToInt32(Console.ReadLine());
        }

        public bool czyPosiada3(int x) 
        { 
            while(x > 0) 
            {
                if(x % 10 == 3)
                {
                    return true;
                }
                x /= 10;
            }

            return false;
        }

        public void wypisz()
        {
            if (czyPosiada3(x))
                Console.WriteLine("Tak");
            else
                Console.WriteLine("Nie");
        }
    }
}
