﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace wprowadzenie
{
    internal class zadanie1_1
    {
        private int suma = 0;
        private int liczby = 0;

        public zadanie1_1() { }

        public void wpisz()
        {
            int x;
            for(int i = 0; i < 10; i++)
            {
                x = Convert.ToInt32(Console.ReadLine());
                if (x % 3 == 0 || x % 5 == 0)
                {
                    suma += x;
                    liczby++;
                }
            }
        }

        public void wypisz()
        {
            Console.WriteLine("Suma: " + suma);
            Console.WriteLine("Srednia: " + (decimal)suma / (decimal)liczby);
        }
    }
}
