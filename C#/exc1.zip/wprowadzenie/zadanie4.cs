﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wprowadzenie
{
    internal class zadanie4
    {
        private int x;

        public zadanie4() { }

        public void wpisz()
        {
            x = Convert.ToInt32(Console.ReadLine());
        }

        public int pierwiastekCyfrowy(int x) 
        {
            while (x > 9)
            {
                int s = 0;
                while (x > 0) 
                {
                    s += x % 10;
                    x /= 10;
                }
                x = s;
            }
            return x;
        }

        public void wypisz()
        {
            Console.WriteLine(pierwiastekCyfrowy(x));
        }
    }
}
