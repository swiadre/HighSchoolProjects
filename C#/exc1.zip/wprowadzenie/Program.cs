﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wprowadzenie
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Zadanie 1:");
            zadanie1 zad1 = new zadanie1();
            zad1.wpisz();
            zad1.wypisz();

            Console.WriteLine("Zadanie 1*: ");
            zadanie1_1 zadanie1_1 = new zadanie1_1();
            zadanie1_1.wpisz();
            zadanie1_1.wypisz();

            Console.WriteLine("Zadanie 2: ");
            zadanie2 zadanie2 = new zadanie2();
            zadanie2.wpisz();
            zadanie2.wypisz();

            Console.WriteLine("Zadanie 2*: ");
            zadanie2_1 zadanie2_1 = new zadanie2_1();
            zadanie2_1.wpisz();
            zadanie2_1.wypisz();

            Console.WriteLine("Zadanie 3: ");
            zadanie3 zadanie3 = new zadanie3();
            zadanie3.wpisz();
            zadanie3.wypisz();

            Console.WriteLine("Zadanie 4: ");
            zadanie4 zadanie4 = new zadanie4();
            zadanie4.wpisz();
            zadanie4.wypisz();

            Console.WriteLine("Zadanie 5: ");
            zadanie5 zadanie5 = new zadanie5();
            zadanie5.wpisz();
            zadanie5.wypisz();

            Console.ReadLine();
        }
    }
}
