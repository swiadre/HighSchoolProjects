﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wprowadzenie
{
    internal class zadanie5
    {
        private string x;

        public zadanie5() { }

        public void wpisz()
        {
            x = Console.ReadLine();
        }

        public string licz(string x) 
        {
            string result = "";
            int count = 1;

            for (int i = 1; i < x.Length; i++)
            {
                if (x[i] == x[i - 1])
                {
                    count++;
                }
                else
                {
                    result += x[i - 1].ToString() + count;
                    count = 1;
                }
            }

            result += x[x.Length - 1].ToString() + count;

            return result;
        }

        public void wypisz()
        {
            Console.WriteLine(licz(x));
        }
    }
}
