﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wprowadzenie
{
    internal class zadanie3
    {
        private string x;

        public zadanie3() { }

        public void wpisz() 
        {
            x = Console.ReadLine();
        }

        public string obroc(string x) 
        {
            string p = "";
            string q = "";
            string t = "";
            
            for(int i = 0; i < x.Length; i++)
            {
                if(!Char.IsLetter(x[i]))
                {
                    t += x[i];
                    for(int j = 0; j < i; j++)
                        p += x[j];

                    for(int j = i+1; j < x.Length; j++)
                        q += x[j];
                    break;
                }
            }

            return q + t + p;
        }

        public void wypisz()
        {
            Console.WriteLine(obroc(x));
        }
    }
}
