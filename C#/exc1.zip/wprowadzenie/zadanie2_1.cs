﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wprowadzenie
{
    internal class zadanie2_1
    {
        private string x;

        public zadanie2_1() { }

        public void wpisz()
        {
            x = Console.ReadLine();
        }

        public bool czyPosiada3(string x)
        {
            if (x.Contains("3"))
                return true;
            return false;
        }

        public void wypisz()
        {
            if (czyPosiada3(x))
                Console.WriteLine("Tak");
            else
                Console.WriteLine("Nie");
        }
    }
}
