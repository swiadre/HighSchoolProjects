﻿using System;
using System.Threading;
using System.Windows;
using System.Net.Sockets;
using System.Net;

namespace LocalHostPortScaner
{
    public partial class MainWindow : Window
    {
        private Thread scanThread;
        private bool isPaused = false;
        private ManualResetEvent pauseEvent = new ManualResetEvent(true);
        private volatile bool stopRequested = false;

        public MainWindow()
        {
            InitializeComponent();
            this.Closing += MainWindow_Closing;
        }


        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (scanThread != null && scanThread.IsAlive)
            {
                if (MessageBox.Show("A scan is still running. Do you want to close anyway?", "Confirm Exit", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    stopRequested = true;
                    scanThread.Join(1000);
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }



        private void ScanPorts(int startPort, int endPort)
        {
            for (int i = startPort; i <= endPort; i++)
            {
                if (stopRequested)
                {
                    Dispatcher.Invoke(() => lblCurrent.Content = "Scan Stopped");
                    break;
                }

                if (isPaused)
                {
                    Dispatcher.Invoke(() => lblCurrent.Content = "Scan Paused at port: " + i);
                    pauseEvent.WaitOne();
                }

                Dispatcher.Invoke(() => lblCurrent.Content = "Currently scanning port: " + i);

                TcpListener server = null;
                try
                {
                    server = new TcpListener(IPAddress.Loopback, i);
                    server.Start();
                }
                catch
                {
                    Dispatcher.Invoke(() => lbHosts.Items.Add("Port: " + i + " is busy"));
                }
                finally
                {
                    server?.Stop();
                }
            }

            Dispatcher.Invoke(() => {
                lblCurrent.Content = "Scan Completed";
                lbHosts.Items.Add("Scan Completed");
                btStartPauseResume.Content = "Start";
                btStartPauseResume.IsEnabled = true;
                btStop.IsEnabled = false;
            });
            stopRequested = false;
        }

        private void btStartPauseResume_Click(object sender, RoutedEventArgs e)
        {
            if (btStartPauseResume.Content.ToString() == "Start")
            {
                if (int.TryParse(tbFrom.Text, out int startPort) && int.TryParse(tbTo.Text, out int endPort))
                {
                    if (startPort <= endPort)
                    {
                        stopRequested = false;
                        isPaused = false;
                        scanThread = new Thread(() => ScanPorts(startPort, endPort));
                        scanThread.Start();

                        btStartPauseResume.Content = "Pause";
                        btStop.IsEnabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Start port must be less than or equal to end port.");

                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Please enter valid numeric values for ports.");

                    return;
                }
            }
            else if (btStartPauseResume.Content.ToString() == "Pause")
            {
                btStartPauseResume.Content = "Resume";
                isPaused = true;
                pauseEvent.Reset();
            }
            else if (btStartPauseResume.Content.ToString() == "Resume")
            {
                btStartPauseResume.Content = "Pause";
                isPaused = false;
                pauseEvent.Set();
            }
        }


        private void btStop_Click(object sender, RoutedEventArgs e)
        {
            if (scanThread != null && scanThread.IsAlive)
            {
                stopRequested = true;
                btStartPauseResume.Content = "Start";
                btStartPauseResume.IsEnabled = true;
                btStop.IsEnabled = false;
            }
        }

    }
}
